package tr.edu.ogu.ceng.Users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class users_applicationTests {

	@Test
	void contextLoads() {
	}

}
